package com.example.admin.service.customer;

import com.example.admin.model.customer.Customer;
import com.example.admin.repository.customer.CustomerRepository;
import com.example.admin.repository.customer.ICustomerRepository;

import java.util.List;

public class CustomerService implements ICustomerService {
    private ICustomerRepository repository = new CustomerRepository();

    @Override
    public List<Customer> getAllCusomter() {
        return repository.getAllCustomer();
    }

    @Override
    public void deleteCustomer(int customer_code) {
        repository.deleteCustomer(customer_code);
    }
}
