package com.example.admin.repository.booking;

import com.example.admin.model.booking.Booking;
import com.example.admin.model.employee.Employee;

import java.util.List;

public interface IBookingRepository {
    List<Booking> getAllBooking();

    void updateBooking(int bookingIdApproved);

    void deleteBooking(int id);

}
