package com.example.admin.service.booking;

import com.example.admin.model.booking.Booking;

import java.util.List;

public interface IBookingService {
    List<Booking> getAllBooking();

    void updateBooking(int bookingIdApproved);

    void deleteBooking(int id);

}
