package com.example.admin.service.booking;

import com.example.admin.model.booking.Booking;
import com.example.admin.repository.booking.BookingRepository;
import com.example.admin.repository.booking.IBookingRepository;


import java.util.List;

public class BookingService implements IBookingService {
    private IBookingRepository repository = new BookingRepository();
    @Override
    public List<Booking> getAllBooking() {
        return repository.getAllBooking();
    }

    @Override
    public void updateBooking(int bookingIdApproved) {
        repository.updateBooking(bookingIdApproved);
    }

    @Override
    public void deleteBooking(int id) {
        repository.deleteBooking(id);
    }
}
