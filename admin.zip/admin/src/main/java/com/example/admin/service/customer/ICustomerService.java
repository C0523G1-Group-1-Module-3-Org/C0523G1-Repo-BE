package com.example.admin.service.customer;

import com.example.admin.model.customer.Customer;

import java.util.List;

public interface ICustomerService {
    List<Customer> getAllCusomter();

    void deleteCustomer(int customer_code);
}
